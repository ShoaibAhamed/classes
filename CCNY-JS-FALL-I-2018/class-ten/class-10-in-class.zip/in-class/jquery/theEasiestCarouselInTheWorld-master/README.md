The easiest carousel in the world using using the jQuery only. 
I put together these codes on my personal research for teaching a CS class at CUNY- LaGuardia Community College. 
